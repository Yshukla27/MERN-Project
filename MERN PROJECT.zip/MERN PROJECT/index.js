require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');

const app = express();

// Import Routes
const indexRoute = require('./routes/indexroute');
const taskRoutes = require('./routes/tasksroute');
const habitRoutes = require('./routes/habitsroute');
const expenseRoutes = require('./routes/expensesroute');

// Database Connection
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('🟢 MongoDB Connected'))
.catch((err) => console.error('🔴 MongoDB Connection Error:', err));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
// View Engine Setup — this MUST come before any res.render() calls
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


// View Engine
app.get('/', (req, res) => {
  res.render('index'); // Make sure views/index.ejs exists
});


// Mount Routes
app.use('/', indexRoute); // ✅ also matches
app.use('/tasks', taskRoutes);       // Tasks Route
app.use('/habits', habitRoutes);     // Habits Route
app.use('/expenses', expenseRoutes); // Expenses Route

// Server Start
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
